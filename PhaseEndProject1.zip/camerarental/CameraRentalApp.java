package camerarental;

import java.util.ArrayList;
import java.util.Scanner;

public class CameraRentalApp {

    private static final String ADMIN_USERNAME = "admin";
    private static final String ADMIN_PASSWORD = "admin123";
    
    private static ArrayList<Camera> cameraList = new ArrayList<>();
    private static double walletBalance = 1000.0;

    public static void main(String[] args) {
        System.out.println("+******************************+");
        System.out.println("| Welcome to Camera Rental App |");
        System.out.println("+******************************+");

        // Adding some default cameras
        cameraList.add(new Camera("Canon", "EOS 5D", 50.0, true));
        cameraList.add(new Camera("Nikon", "D750", 40.0, true));
        cameraList.add(new Camera("Sony", "Alpha A7 III", 60.0, true));

        login(); // Added login before displaying options
        optionsSelection();
    }

    private static void login() {
        Scanner scanner = new Scanner(System.in);

        System.out.println(" PLEASE LOGIN TO CONTINUE ");
        System.out.print("Enter username: ");
        String username = scanner.nextLine();
        System.out.print("Enter password: ");
        String password = scanner.nextLine();

        // For simplicity, using static credentials for admin login
        if (ADMIN_USERNAME.equals(username) && ADMIN_PASSWORD.equals(password)) {
            System.out.println("Login successful! Welcome, Admin.");
        } else {
            System.out.println("Login failed! Exiting the application.");
            System.exit(0);
        }
    }

    private static void optionsSelection() {
        while (true) {
            System.out.println("\n1. List Cameras");
            System.out.println("2. Rent a Camera");
            System.out.println("3. Add or View Wallet Balance");
            System.out.println("4. Add a Camera");
            System.out.println("5. Exit");

            Scanner scanner = new Scanner(System.in);
            System.out.print("\nEnter your choice: ");

            int option = scanner.nextInt();

            switch (option) {
                case 1:
                    listCameras();
                    break;
                case 2:
                    rentCamera();
                    break;
                case 3:
                    viewWalletBalance();
                    break;
                case 4:
                    addCamera();
                    break;
                case 5:
                    System.out.println("Thank you for using Camera Rental App. Exiting the application.");
                    System.exit(0);
                default:
                    System.out.println("Invalid choice! Please try again.");
                    break;
            }
        }
    }

    private static void listCameras() {
        if (cameraList.isEmpty()) {
            System.out.println("No cameras available for rent at the moment.");
        } else {
            System.out.println("\nList of Cameras available for rent:");
            for (Camera camera : cameraList) {
                System.out.println(camera);
            }
        }
    }

    private static void rentCamera() {
        Scanner scanner = new Scanner(System.in);

        if (cameraList.isEmpty()) {
            System.out.println("No cameras available for rent at the moment.");
            return;
        }

        System.out.println("\nSelect a camera to rent:");
        for (int i = 0; i < cameraList.size(); i++) {
            System.out.println((i + 1) + ". " + cameraList.get(i));
        }

        System.out.print("Enter the number of the camera you want to rent: ");
        int cameraNumber = scanner.nextInt();

        if (cameraNumber >= 1 && cameraNumber <= cameraList.size()) {
            Camera selectedCamera = cameraList.get(cameraNumber - 1);
            if (selectedCamera.isAvailable() && walletBalance >= selectedCamera.getRentAmount()) {
                System.out.println("Renting " + selectedCamera.getBrand() + " " +
                        selectedCamera.getModel() + " for $" + selectedCamera.getRentAmount() + " per day.");
                walletBalance -= selectedCamera.getRentAmount();
                selectedCamera.setAvailable(false);
                System.out.println("Camera rented successfully!");
            } else {
                System.out.println("Selected camera is not available or insufficient balance in your wallet.");
            }
        } else {
            System.out.println("Invalid camera selection.");
        }
    }

    private static void viewWalletBalance() {
        System.out.println("\nWallet Balance: $" + walletBalance);
    }

    private static void addCamera() {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter the brand of the camera: ");
        String brand = scanner.nextLine();
        System.out.print("Enter the model of the camera: ");
        String model = scanner.nextLine();
        System.out.print("Enter the per-day rental amount: ");
        double rentAmount = scanner.nextDouble();

        Camera newCamera = new Camera(brand, model, rentAmount, true);
        cameraList.add(newCamera);

        System.out.println("Camera added successfully!");
    }
}

class Camera {
    private String brand;
    private String model;
    private double rentAmount;
    private boolean available;

    public Camera(String brand, String model, double rentAmount, boolean available) {
        this.brand = brand;
        this.model = model;
        this.rentAmount = rentAmount;
        this.available = available;
    }

    public String getBrand() {
        return brand;
    }

    public String getModel() {
        return model;
    }

    public double getRentAmount() {
        return rentAmount;
    }

    public boolean isAvailable() {
        return available;
    }

    public void setAvailable(boolean available) {
        this.available = available;
    }

    @Override
    public String toString() {
        return "Camera{" +
                "brand='" + brand + '\'' +
                ", model='" + model + '\'' +
                ", rentAmount=" + rentAmount +
                ", available=" + available +
                '}';
    }
}